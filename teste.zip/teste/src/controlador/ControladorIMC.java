
package controlador;

import com.jfoenix.controls.JFXComboBox;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class ControladorIMC implements Initializable{

    enum Sexo {
        MASC,
        FEM
    };
    
    @FXML
    JFXComboBox IMC;
    
    ObservableList<Sexo> sexo;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        sexo.addAll(Sexo.values());
        IMC.setItems(sexo);
    
    }
}
