
package persistence;

public class UsuarioDAO {
    
}
