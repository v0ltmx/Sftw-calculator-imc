
CREATE TABLE IF NOT EXISTS TRABALHO (
    nome varchar(255) NOT NULL PRIMARY KEY, 
    altura double,
    peso double, 
    idade int,
    novaconsulta double,
    antigaconsulta double
);