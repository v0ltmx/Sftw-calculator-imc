
package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import modelo.Usuario;


public class ControladorUsuario implements Initializable{
    
    Usuario usuario;
    
    @FXML
    Label nomeuser, imcResult, statusResul;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nomeuser.setText(usuario.getNome());
        //imcResult.setText();
        statusResul.setText("Buceta do Resultado");
    }
}
