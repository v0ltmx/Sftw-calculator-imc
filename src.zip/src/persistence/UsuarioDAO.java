
package persistence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import modelo.Usuario;

public class UsuarioDAO {
    
    private final Conexao con = new Conexao();
    
    private final String INSERTUSUARIO = "INSERT INTO PROJETO (nome, altura, peso, idade) VALUES (?,?,?,?)";
    private final String UPDATEPESO = "UPDATE PROJETO SET peso = ?";
//    private final String LISTPESO = "SELECT peso FROM PROJETO";
    private final String UPDATEALTURA = "UPDATE PROJETO SET altura = ?";
//    private final Strgin LISTALTURA = "SELECT altura FROM PROJETO";
    private final String DELETEUSUARIO = "DELETE FROM PROJETO WHERE nome = ?";
    
    public boolean insertUsuario(Usuario u){
        try{
            con.conecta();
            PreparedStatement preparaInstrucao;
            preparaInstrucao = con.getConexao().prepareStatement(INSERTUSUARIO);
            
            preparaInstrucao.setString(1, u.getNome().toUpperCase());
            preparaInstrucao.setDouble(2, u.getAltura());
            preparaInstrucao.setDouble(3, u.getPeso());
            preparaInstrucao.setInt(4, u.getIdade());
            
            preparaInstrucao.execute();
            
            con.desconecta();
            
            return true;
            
        } catch (SQLException e){
            return false;
        }
    }
    
    
    public boolean updatePeso(Usuario u){
    
        try{
            con.conecta();
            PreparedStatement preparaInstrucao;
            preparaInstrucao = con.getConexao().prepareStatement(UPDATEPESO);
            
            preparaInstrucao.setDouble(1, u.getPeso());
            
            preparaInstrucao.execute();
            
            con.desconecta();
            
            return true;
        } 
        catch(SQLException e){
            return false;
        }
 
    }
    
    public boolean updateAltura(Usuario u){
        try{
            con.conecta();
            PreparedStatement preparaInstrucao;
            preparaInstrucao = con.getConexao().prepareStatement(UPDATEALTURA);
            
            preparaInstrucao.setDouble(1, u.getPeso());
            
            preparaInstrucao.execute();
            
            con.desconecta();
            
            return true;
        }
        catch (SQLException e){
            return false;
        }
    
    }
    /*
    public boolean listAltura(Usuario u){
        try{
            con.conecta();
            PreparedStatement preparaInstrucao;
            preparaInstrucao = con.getConexao().prepareStatement(LISTALTURA);
            
            preparaInstrucao.
        }
        catch(SQLException e){
            return false;
        }
    }
    */
    public boolean deleteUsuario(Usuario u){
        try{
            
            con.conecta();
            PreparedStatement preparaInstrucao;
            preparaInstrucao = con.getConexao().prepareStatement(DELETEUSUARIO);
            
            preparaInstrucao.setString(1, u.getNome().toUpperCase());
            
            preparaInstrucao.execute();
            
            con.desconecta();
            
            return true;
        }
        catch(SQLException e) {
            return false;
        }
    }
}